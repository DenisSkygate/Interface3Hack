<?php
/**
 * Plugin
 * 
 * @since 1.0.0
 */
interface Astoundify_PluginInterface {
	public static function init();
	public static function setup_actions();
}
