<?php
/**
 * Use the same as `content-job_listing.php`
 *
 * @since 3.0.0
 */

get_template_part( 'content', 'job_listing' );
