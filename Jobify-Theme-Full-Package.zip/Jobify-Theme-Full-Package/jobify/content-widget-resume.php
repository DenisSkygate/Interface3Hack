<?php
/**
 * Resume content for widgets
 *
 * @since 3.2.0
 */

locate_template( array( 'content-resume.php' ), true, false );
